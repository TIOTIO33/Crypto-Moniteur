
import streamlit as st
import requests
import time
import pandas as pd
import altair as alt

st.set_page_config(page_title="Moniteur Crypto", layout="wide")

# Liste des cryptos et des exchanges
cryptos = ["bitcoin", "ethereum", "solana", "cardano", "ripple", "dogecoin"]
exchanges = {
    "Binance": "binance",
    "Coinbase": "coinbase",
    "Kraken": "kraken",
    "Bitfinex": "bitfinex",
    "Bitstamp": "bitstamp",
    "Bybit": "bybit",
    "OKX": "okx",
    "Gate.io": "gate",
    "KuCoin": "kucoin",
    "Crypto.com": "crypto_com"
}

st.title("🪙 Tableau de Bord Crypto")
st.markdown("### Prix en direct (actualisé toutes les 60 secondes)")

selected_crypto = st.selectbox("Choisis une crypto :", cryptos)
refresh_interval = st.slider("Intervalle de mise à jour (sec)", 15, 300, 60)

@st.cache_data(ttl=refresh_interval)
def fetch_prices(crypto):
    prices = []
    for name, exchange in exchanges.items():
        try:
            url = f"https://api.coingecko.com/api/v3/simple/price?ids={crypto}&vs_currencies=usd&include_last_updated_at=true"
            r = requests.get(url)
            data = r.json()
            price = data[crypto]["usd"]
            timestamp = data[crypto].get("last_updated_at", int(time.time()))
            prices.append({
                "Exchange": name,
                "Crypto": crypto.capitalize(),
                "Price (USD)": price,
                "Timestamp": pd.to_datetime(timestamp, unit="s")
            })
        except Exception as e:
            prices.append({
                "Exchange": name,
                "Crypto": crypto.capitalize(),
                "Price (USD)": "N/A",
                "Timestamp": pd.NaT
            })
    return pd.DataFrame(prices)

df = fetch_prices(selected_crypto)

col1, col2 = st.columns([2, 3])

with col1:
    st.subheader(f"Prix de {selected_crypto.capitalize()} par exchange")
    st.dataframe(df, use_container_width=True)

with col2:
    st.subheader("Graphique des prix")
    chart = alt.Chart(df.dropna()).mark_bar().encode(
        x="Exchange",
        y="Price (USD)",
        tooltip=["Exchange", "Price (USD)"]
    ).properties(height=400)
    st.altair_chart(chart, use_container_width=True)

st.caption("Données via l’API CoinGecko. Actualisé automatiquement.")
