
# 📊 Crypto Exchange Monitor

Un tableau de bord en Python pour suivre en temps réel les prix de plusieurs cryptomonnaies sur différents exchanges.

## ✅ Fonctions :
- Prix live (via CoinGecko)
- Affichage par exchange
- Graphique dynamique
- Interface via Streamlit

## 🚀 Lancer en local

```bash
pip install -r requirements.txt
streamlit run app.py
```

## ☁️ Hébergement gratuit

1. Pousse ce repo sur GitHub
2. Va sur https://streamlit.io/cloud
3. Clique sur "New app" > sélectionne ton repo GitHub
4. Renseigne : `app.py` comme fichier principal
5. Clique sur "Deploy"

Enjoy! 🎉
